---
name: Patitas Felices Clinical Care
colors:
  surface: '#fbf8ff'
  surface-dim: '#d3d8ff'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2ff'
  surface-container: '#ececff'
  surface-container-high: '#e5e6ff'
  surface-container-highest: '#dee0ff'
  on-surface: '#111840'
  on-surface-variant: '#454651'
  inverse-surface: '#262d56'
  inverse-on-surface: '#f0efff'
  outline: '#767683'
  outline-variant: '#c6c5d3'
  surface-tint: '#4a57aa'
  primary: '#112175'
  on-primary: '#ffffff'
  primary-container: '#2c3a8c'
  on-primary-container: '#9ca9ff'
  inverse-primary: '#bbc3ff'
  secondary: '#585798'
  on-secondary: '#ffffff'
  secondary-container: '#b9b7ff'
  on-secondary-container: '#474685'
  tertiary: '#2a2557'
  on-tertiary: '#ffffff'
  tertiary-container: '#403c6f'
  on-tertiary-container: '#aea8e3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dee0ff'
  primary-fixed-dim: '#bbc3ff'
  on-primary-fixed: '#000f5d'
  on-primary-fixed-variant: '#313f91'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c2c1ff'
  on-secondary-fixed: '#141051'
  on-secondary-fixed-variant: '#413f7f'
  tertiary-fixed: '#e4dfff'
  tertiary-fixed-dim: '#c6c0fc'
  on-tertiary-fixed: '#191446'
  on-tertiary-fixed-variant: '#454174'
  background: '#fbf8ff'
  on-background: '#111840'
  surface-variant: '#dee0ff'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 42px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies veterinary medical precision married with domestic empathy. It establishes an atmosphere of calm authority, clinical competence, and reassurance for pet guardians, while maintaining the streamlined efficiency required by veterinary professionals.

### Design Movement
**Modern Clinical-Friendly**: A blend of corporate healthcare clarity and warm hospitality. The visual style avoids cold, sterile tropes by using softened geometry, luminous lavender-tinted surfaces, and layered tactile depth, while preserving rigorous data display density, clear affordances, and unmistakable status communications.

### Personality & Emotional Response
- **Trustworthy & Authoritative**: Grounded in deep French Blue and clear typography that projects institutional reliability.
- **Empathetic & Calming**: Soft periwinkle and delicate lavender undertones reduce anxiety during stressful clinical visits or triage scenarios.
- **Efficient & Accessible**: Rapid scanning of complex patient charts, biometric logs, and vaccination schedules without visual fatigue.

## Colors

The palette is engineered with clinical purpose, balancing high-contrast readouts against soft, ambient surfaces to mitigate optical glare across veterinary clinics and mobile customer portals.

### Color Roles & Tonal Strategy
- **Primary (`#2c3a8c` - French Blue)**: Reserved for high-priority interactive calls-to-action, structural navigation banners, active tab indicators, and critical patient statuses.
- **Secondary (`#6766a8` - Dusty Grape)**: Applied to secondary workflows, supporting metadata icons, active filters, badge backgrounds, and secondary button borders.
- **Tertiary (`#9f9ad4` - Soft Periwinkle)**: Used for subtle decorative outlines, progress meter tracks, active step indicators, and soft toggle accents.
- **Neutral Deep (`#1e254d`)**: Primary text color for maximum legibility and strict contrast compliance (WCAG AAA against pure white).
- **Neutral Light & Surfaces**:
  - `Base Canvas`: `#ffffff` (Pure White for critical forms, modal bodies, and clinical data panels).
  - `Subtle Surface`: `#f4f3f9` (Soft Lavender Tint for page foundations, alternating row treatments, and muted layout containers).
  - `Container Accent`: `#e6e4f1` (Lavender Accent for unselected chip states, subtle borders, input outlines, and card resting strokes).
- **Functional Semantics**:
  - `Success`: `#238652` / Muted tint: `#e8f6ee` (Completed appointments, healthy vitals).
  - `Warning`: `#b87309` / Muted tint: `#fdf6e7` (Vaccines expiring soon, triage alerts).
  - `Danger`: `#c7283c` / Muted tint: `#faebee` (Medical emergencies, critical vitals).

## Typography

**Plus Jakarta Sans** governs the typography hierarchy across the entire ecosystem. Its clean geometric architecture ensures reliable clinical readability, while humanist terminals bring warmth and accessibility to pet guardians.

### Scaling & Legibility Strategy
- **Display & Headlines**: Bold, affirmative weightings designed for rapid scanning of pet summaries, patient names, and primary dashboard metrics.
- **Body & Data Tables**: Rigorously tuned optical letter-spacing with open apertures, facilitating effortless reading of medication dosages, diagnosis logs, and weight graphs.
- **Labels & Micro-indicators**: Rendered in semi-bold and bold weights for status indicators, calendar slots, and vital tags, maintaining clear contrast against lavender-tinted background pills.

## Layout & Spacing

The layout model uses an adaptive fluid-grid structure that shifts dynamically between clinic management consoles and patient companion viewports.

### Grid & Breakpoints
- **Desktop (≥1200px)**: 12-column responsive layout with `2rem` outer margins and `1.5rem` gutters. Accommodates side-by-side patient queues, medical history feeds, and appointment sidebars.
- **Tablet (768px - 1199px)**: 8-column layout with `1.5rem` outer margins and `1rem` gutters. Sidebar navigations collapse into drawer menus.
- **Mobile (≤767px)**: 4-column layout with `1rem` margins and `1rem` gutters. Elements reflow into stacked cards and sticky bottom task bars for single-thumb portal operation.

### Spacing Rhythm
Component spacing follows strict 4px/8px incremental multiples:
- Micro gaps (`space-xs` = 4px, `space-sm` = 8px) unify internal button padding, pet tag icons, and compact data pairings.
- Structural card padding utilizes `space-md` (16px) on mobile and `space-lg` (24px) on desktop surfaces.
- Section isolation utilizes `space-xl` (40px) to distinguish clinical panels without visual clutter.

## Elevation & Depth

The design system achieves visual hierarchy using tinted ambient depth rather than generic neutral drop shadows. Every elevated surface is cast with a subtle indigo/lavender bias to reinforce clinical calm.

### Elevation Hierarchy
- **Level 0 (Flat / Canvas)**: Surface background (`#f4f3f9`). Zero elevation, grounding full-bleed layout modules.
- **Level 1 (Card & Module Resting)**: Pure white `#ffffff` fill with a subtle perimeter border (`1px solid #e6e4f1`) and an ambient shadow:
  `box-shadow: 0 4px 16px -2px rgba(44, 58, 140, 0.04), 0 2px 6px -1px rgba(103, 102, 168, 0.03);`
- **Level 2 (Hover & Active Selection)**: Slightly pronounced elevation for cards during user pointer interactions:
  `box-shadow: 0 10px 24px -4px rgba(44, 58, 140, 0.08), 0 4px 8px -2px rgba(103, 102, 168, 0.04);`
- **Level 3 (Overlays, Floating Actions & Modals)**: Critical triage panels, date pickers, and popovers:
  `box-shadow: 0 20px 32px -8px rgba(44, 58, 140, 0.14), 0 8px 16px -4px rgba(30, 37, 77, 0.06);`

## Shapes

The geometric silhouette combines clean architecture with gentle, protective curvature. Elements maintain defined structural integrity while avoiding sharp, aggressive corners.

### Shape Scale Application
- **Standard (`0.5rem` / 8px)**: Inputs, small buttons, form controls, and nested list items.
- **Large (`1rem` / 16px - `rounded-lg`)**: Primary cards, prescription review blocks, medical charts, and summary panels.
- **Extra Large (`1.5rem` / 24px - `rounded-xl`)**: Top-level modal dialogues, dashboard summary widgets, and client profile hero containers.
- **Full Pill (`9999px`)**: Status tags, pet breed indicators, vital badge metrics, and quick filter chips.

## Components

### Buttons
- **Primary Button**: Solid French Blue (`#2c3a8c`) background, white text (`#ffffff`), `rounded-lg` (12px), `0.75rem 1.5rem` padding. Subtle hover shifts to `#232f72` with an ambient glow. Focus ring: `3px solid #9f9ad4`.
- **Secondary Button**: Outlined in Dusty Grape (`1.5px solid #6766a8`), clear or `#ffffff` background, `#2c3a8c` text. Hover fills with `#f4f3f9`.
- **Tertiary / Ghost Button**: Transparent background, `#2c3a8c` font, with a soft lavender tint (`#e6e4f1`) appearing on hover.

### Chips & Badges
- **Status Badges**: Pill-shaped (`rounded-full`), `space-xs space-sm` (4px 10px) padding.
  - Active / Vaccinated: `#e8f6ee` background with `#238652` bold label.
  - Triage Pending: `#fdf6e7` background with `#b87309` bold label.
  - Species / Pet Category: `#e6e4f1` background with `#2c3a8c` label.
- **Filter Chips**: Resting state in `#ffffff` with `1px solid #e6e4f1`. Active selection filled with `#2c3a8c` with white typography.

### Input Fields & Controls
- **Inputs**: Background `#ffffff`, text `#1e254d`, border `1.5px solid #e6e4f1`, `rounded-md` (8px). Focused state transitions border to `#2c3a8c` with a soft outer ring in `#9f9ad4` (0 0 0 3px).
- **Checkboxes & Radios**: Custom checks in French Blue (`#2c3a8c`) with crisp white interior marks. Disabled states resolve to muted lavender grey (`#e6e4f1`).

### Cards & Patient Containers
- Elevated white surface on soft lavender foundation. Includes a defined header area separated by a low-contrast divider (`1px solid #f4f3f9`).
- Contains modular subsections for quick diagnosis, microchip references, and owner emergency dials.

### Specialized Veterinary Components
- **Patient Banner Card**: Houses pet profile thumbnail, species, breed, age, weight, and critical medical alerts in high-contrast badge tiers.
- **Vaccine Timeline Tracker**: Uses Soft Periwinkle tracks (`#9f9ad4`) connecting circular status checkpoints with clear French Blue indicators for upcoming renewals.
- **Appointment Slot Matrix**: Lavender-tinted grid items (`#f4f3f9`) that elevate to French Blue (`#2c3a8c`) with inverted white typography upon booking confirmation.